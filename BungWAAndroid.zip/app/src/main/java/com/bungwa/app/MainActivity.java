package com.bungwa.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText numberInput;
    private TextView status;
    private final int bg = Color.rgb(8,8,8);
    private final int panel = Color.rgb(24,24,24);
    private final int green = Color.rgb(37,211,102);
    private final int white = Color.WHITE;
    private final int muted = Color.rgb(170,170,170);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(24));
        scroll.addView(root);

        TextView logo = text("BUNG WA", 30, green, true);
        root.addView(logo);
        TextView subtitle = text("WhatsApp Number Toolkit", 14, muted, false);
        root.addView(subtitle);

        View gap = new View(this); root.addView(gap, new LinearLayout.LayoutParams(1, dp(26)));
        TextView heading = text("Masukkan nomor tujuan", 18, white, true);
        root.addView(heading);

        numberInput = new EditText(this);
        numberInput.setSingleLine(true);
        numberInput.setHint("Contoh: 081234567890");
        numberInput.setHintTextColor(Color.GRAY);
        numberInput.setTextColor(white);
        numberInput.setTextSize(16);
        numberInput.setInputType(3);
        numberInput.setPadding(dp(14), dp(13), dp(14), dp(13));
        numberInput.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, dp(54));
        inputParams.topMargin = dp(12);
        root.addView(numberInput, inputParams);

        status = text("Nomor Indonesia boleh dimulai dengan 08, 62, atau +62.", 13, muted, false);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(10);
        root.addView(status, statusParams);

        addGap(root, 22);
        addButton(root, "BUKA CHAT WHATSAPP", green, Color.BLACK, v -> openWhatsApp());
        addButton(root, "SALIN NOMOR FORMAT INTERNASIONAL", panel, white, v -> copyNumber());
        addButton(root, "BERSIHKAN", panel, white, v -> {
            numberInput.setText("");
            status.setText("Kolom nomor dibersihkan.");
        });

        addGap(root, 20);
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(16), dp(16), dp(16), dp(16));
        info.setBackgroundColor(panel);
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));
        info.addView(text("FITUR", 14, green, true));
        info.addView(text("• Validasi sederhana nomor telepon\n• Otomatis ubah 08 menjadi 628\n• Buka percakapan melalui WhatsApp resmi\n• Salin nomor internasional\n• Tidak perlu login dan tidak menyimpan nomor", 14, white, false));

        addGap(root, 18);
        root.addView(text("Privasi: aplikasi ini hanya membuka chat yang dipilih pengguna. Tidak ada fitur spam, pengiriman massal, atau gangguan akun.", 12, muted, false));

        setContentView(scroll);
    }

    private void openWhatsApp() {
        String number = normalizedNumber();
        if (number == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://wa.me/" + number));
            startActivity(intent);
            status.setText("Membuka WhatsApp untuk +" + number);
        } catch (Exception e) {
            status.setText("Tidak bisa membuka tautan. Pastikan browser tersedia.");
        }
    }

    private void copyNumber() {
        String number = normalizedNumber();
        if (number == null) return;
        ClipboardManager clipboard = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Nomor WhatsApp", "+" + number));
        status.setText("Nomor +" + number + " berhasil disalin.");
    }

    private String normalizedNumber() {
        String raw = numberInput.getText().toString().trim();
        String n = raw.replaceAll("[^0-9]", "");
        if (n.startsWith("0")) n = "62" + n.substring(1);
        else if (raw.startsWith("+")) { /* already stripped to digits */ }
        else if (!n.startsWith("62")) n = "62" + n;

        if (n.length() < 9 || n.length() > 15 || !n.startsWith("62")) {
            status.setText("Nomor tidak valid. Masukkan nomor Indonesia yang benar.");
            return null;
        }
        return n;
    }

    private void addButton(LinearLayout root, String label, int color, int textColor, View.OnClickListener action) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(textColor);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54));
        p.topMargin = dp(10);
        root.addView(b, p);
        b.setOnClickListener(action);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void addGap(LinearLayout root, int height) {
        View v = new View(this);
        root.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }
    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
